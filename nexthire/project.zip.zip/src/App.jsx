import { useEffect, useState } from "react";
import Login from "./Login";
import Signup from "./Signup";
import Dashboard from "./Dashboard";
import ResumeAnalyzer from "./ResumeAnalyzer";
import MockInterview from "./MockInterview";

function App() {
  const [currentPage, setCurrentPage] = useState("login");

  useEffect(() => {
    const openResume = () => setCurrentPage("resume");

    const openMockInterview = () =>
      setCurrentPage("mock-interview");

    const openDashboard = () =>
      setCurrentPage("dashboard");

    window.addEventListener(
      "open-resume-analyzer",
      openResume
    );

    window.addEventListener(
      "open-mock-interview",
      openMockInterview
    );

    window.addEventListener(
      "open-dashboard",
      openDashboard
    );

    return () => {
      window.removeEventListener(
        "open-resume-analyzer",
        openResume
      );

      window.removeEventListener(
        "open-mock-interview",
        openMockInterview
      );

      window.removeEventListener(
        "open-dashboard",
        openDashboard
      );
    };
  }, []);

  function handleLogin() {
    setCurrentPage("dashboard");
  }

  function handleSignup() {
    setCurrentPage("signup");
  }

  if (currentPage === "signup") {
    return (
      <Signup
        onLogin={() => setCurrentPage("login")}
        onSignup={handleLogin}
      />
    );
  }

  if (currentPage === "resume") {
    return <ResumeAnalyzer />;
  }

  if (currentPage === "mock-interview") {
    return <MockInterview />;
  }

  if (currentPage === "dashboard") {
    return <Dashboard />;
  }

  return (
    <Login
      onLogin={handleLogin}
      onSignup={handleSignup}
    />
  );
}

export default App;